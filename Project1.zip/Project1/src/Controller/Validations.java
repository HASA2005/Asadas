package Controller;

/**
 *
 * @author Cliente
 */
public class Validations {
    
}
