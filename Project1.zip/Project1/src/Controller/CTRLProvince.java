package Controller;

/**
 *
 * @author Cliente
 */
public class CTRLProvince {
    
}
