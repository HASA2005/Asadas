
package Controller;

/**
 *
 * @author Cliente
 */
public class CTRLRole {
    
}
